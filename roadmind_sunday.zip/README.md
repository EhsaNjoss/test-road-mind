# Roadmind

**Traffic lights that think about people.**

Roadmind is an AI traffic-signal **advisor** for busy junctions in Bangladeshi cities. A camera watches the junction, AI detects and tracks every vehicle on each road, estimates how many **people** are waiting, and recommends green time to the **traffic officer** — explained in simple Bangla. The officer always decides. Roadmind never controls real signals.

> Built for the CoU AI Hackathon 2026 by team **IIUC_ZeroCode** (CSE, International Islamic University Chittagong).

## Team
- **Ehsanul Alam** — lead developer
- **K.A Shahriar Rubaiyat** — data & evaluation
- **MD. Ikram Hossain Sami** — testing, deployment & docs

## Status
🚧 In progress — this README is completed as features are built.

Working so far:
- Live detection and tracking of vehicles and people, counted per road zone (queue and longest wait)
- People-first estimate from editable occupancy values (bus ≈ 40, CNG ≈ 3, car ≈ 1.5 …)
- Timing advisor: green time split by people waiting, with min/max green and a fairness guard
- Bangla + English explanation (template; Gemini rewording only if it keeps the same numbers)
- Officer dashboard: Accept / Override with a reason, decision log, EN/বাংলা switch

## Run locally (current stage)
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate    macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
# tests: pip install -r requirements-dev.txt && pytest -q
cp .env.example .env          # Windows: copy .env.example .env
# put a junction video at data/clips/demo.mp4
uvicorn app.main:app --reload
```
Open http://localhost:8000 for the live view and http://localhost:8000/calibrate to draw the road zones.

## AI tools used
- **Claude (Anthropic)** — coding assistance and drafting documentation
- **Google Gemini** — optional rewording of the Bangla explanation
- **YOLO (Ultralytics)** — vehicle and pedestrian detection

See [CREDITS.md](CREDITS.md) for all libraries, models and data.
