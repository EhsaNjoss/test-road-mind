# Sunday (22 Nov) — 4 commits

**Before you start:** unzip this over your repo folder and let it replace files.
Do NOT commit this COMMITS.md file. Delete it, or untick it in GitHub Desktop.

In GitHub Desktop, tick **only** the files listed for a commit. Type the message, then press **Commit to main**.
Make the commits in this order. Spread them across the day, and press **Push origin** after each one (or at the end).

---

### Commit 1 — morning
**Message:** `Add people-first estimate with editable occupancy`
Files:
- `app/core/people.py`
- `app/video/annotate.py`
- `app/video/tracker.py`

### Commit 2 — midday
**Message:** `Add timing advisor and Bangla explanations with tests`
Files:
- `app/core/advisor.py`
- `app/core/explain.py`
- `tests/test_core.py`
- `requirements.txt`
- `requirements-dev.txt`
- `.env.example`

### Commit 3 — afternoon
**Message:** `Add decision log, junction validation and advice loop`
Files:
- `app/db.py`
- `app/junctions.py`
- `app/pipeline.py`
- `app/main.py`
- `.gitignore`

### Commit 4 — evening
**Message:** `Add officer dashboard with Accept/Override and EN/Bangla`
Files:
- `app/static/index.html`
- `app/static/app.js`
- `app/static/styles.css`
- `app/static/calibrate.html`
- `app/static/fonts/` (all 7 font files)
- `README.md`
- `CREDITS.md`

---

**Check before you push:**
- `.env` must NOT appear in the list. It is ignored by `.gitignore`.
- `models/yolo11n.pt` must NOT appear either. It downloads by itself on the first run.

**Test after commit 4:**
```
pip install -r requirements-dev.txt
pytest -q            # should print: 8 passed
uvicorn app.main:app --reload
```
Open http://localhost:8000/calibrate, draw the zones and press Save. Then open http://localhost:8000.
